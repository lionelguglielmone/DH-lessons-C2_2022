package week_5.lesson1;

public interface ImpuestoGravable {

    Double gravar(Double porcentaje);
}
