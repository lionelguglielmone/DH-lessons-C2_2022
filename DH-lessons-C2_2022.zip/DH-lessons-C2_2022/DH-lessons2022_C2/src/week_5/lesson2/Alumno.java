package week_5.lesson2;

public class Alumno {
    //atributos
    private String nombreApellido;
    private String legajo;

    //constructor

    public Alumno(String nombreApellido, String legajo) {
        this.nombreApellido = nombreApellido;
        this.legajo = legajo;
    }
}
