package week_4.sundayStreaming;

public class Cine {
    //atributos
    private String nombre;
    private Pelicula pelicula;
    private String direccion;
    private Integer capacidad;

    //constructor

    public Cine(String nombre, Pelicula pelicula, String direccion, Integer capacidad) {
        this.nombre = nombre;
        this.pelicula = pelicula;
        this.direccion = direccion;
        this.capacidad = capacidad;
    }


    //metodos
}
