package week_3.lesson1;

public class Test {
    public static void main(String[] args) {

        Perro ozzy = new Perro("ozzy");
        Perro perritoHomeless = new Perro("NN");
        Duenio lio = new Duenio("lio", ozzy);

        Perro luli = new Perro("luli");
        Duenio marta = new Duenio("marta", luli);


    }
}
