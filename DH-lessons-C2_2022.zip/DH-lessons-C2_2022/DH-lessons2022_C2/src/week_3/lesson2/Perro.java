package week_3.lesson2;

public class Perro extends Mascota{
    //atributos
    private Boolean tieneColaCortada;

    public Boolean getTieneColaCortada() {
        return tieneColaCortada;
    }

    public void setTieneColaCortada(Boolean tieneColaCortada) {
        this.tieneColaCortada = tieneColaCortada;
    }
}
