package week_3.lesson2;

public class Gato extends Mascota{
    //atributos
    private Boolean tieneGatitits;

    public Boolean getTieneGatitits() {
        return tieneGatitits;
    }

    public void setTieneGatitits(Boolean tieneGatitits) {
        this.tieneGatitits = tieneGatitits;
    }
}
