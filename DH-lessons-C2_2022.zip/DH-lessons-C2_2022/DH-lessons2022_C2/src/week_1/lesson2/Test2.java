package week_1.lesson2;
public class Test2 {
    public static void main(String[] args) {
        String nombre = "pepe";
        nombre = nombre.toUpperCase();

        //System.out.println(nombre.toUpperCase());
        //System.out.println(nombre);

        System.out.println(nombre.equals("PIPA"));
        System.out.println(nombre.equals("pepe"));
        System.out.println(nombre.equals("PEPE"));

    }

}
